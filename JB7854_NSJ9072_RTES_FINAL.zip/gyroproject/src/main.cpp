#include <mbed.h>

SPI spi(PF_9, PF_8, PF_7); // mosi, miso, sclk
DigitalOut chipselect(PC_1);

//The function xlxhconcatenates the xl and xl values and returns the concatenated value
int16_t xlxhconcatenate(int16_t xl, int16_t xh)
{
  int16_t temp;
  temp = 0;
  int16_t z = xl;
  while (xh > 0)
  {

    temp = (temp * 16) + (xh % 16);
    xh = xh / 16;
  }
  while (temp > 0)
  {

    z = (z * 16) + (temp % 16);
    temp = temp / 16;
  }
  return z;
}

//Main function
int main()
{

  // Chip must be deselected
  chipselect = 1;
  int i;
  double linearvelocity[40], Distancetravelled[40];

  // Setup the spi for 8 bit data, high steady state clock,
  // second edge capture, with a 1MHz clock rate
  spi.format(8, 3);
  spi.frequency(1000000);

  double Angularvelocity[40];
  int16_t xl[40], xh[40];

  while (true)
  {

    //PART-1: READING VALUES FROM GYROSCOPE

    // Select the device by setting chip select low
    chipselect = 0;

    // Send 0x8f, the command to read the CTRL_REG1 register
    spi.write(0x20);

    //Assigning bits for PD, Zen, Yen, Xen
    spi.write(0b00001111);
    chipselect = 1;
    chipselect = 0;
    spi.write(0xA8);
    int16_t reg = spi.write(0x00);
    //printf("register = 0x%X\n", reg);

    // read the value to X_h and x_l
    // Send a dummy byte to receive the contents of the CTRL_REG1 register
    // chipselect = 1;
    // chipselect = 0;
    // spi.write(0b10101000);

    for (int i = 0; i < 40; i++)
    {
      chipselect = 1;
      chipselect = 0;
      spi.write(0b10101000);
      xl[i] = spi.write(0x00);
      //printf("xl[i] = %d \n",xl[i]);
      chipselect = 1;
      chipselect = 0;
      spi.write(0b10101001);
      xh[i] = spi.write(0x00);

      //PART 2: CONVERTING ANGULAR VELOCITY TO LINEAR VELOCITY

      Angularvelocity[i] = xlxhconcatenate(xl[i], xh[i]);
      Angularvelocity[i] = ((double)Angularvelocity[i] * 0.00747680664);
      printf("Angularvelocity values= %lf\n ", Angularvelocity[i]);

      //PART 3: CALCULATING THE LINEAR VELOCITY

      linearvelocity[i] = (((Angularvelocity[i] * 3.14) / 180) * 83);
      printf("Linear velocity values= %lf \n ", linearvelocity[i]);

      //PART 3: CALCULATING THE DISTANCE TRAVELLED

      Distancetravelled[i] = (((double)linearvelocity[i]) * 0.5);

      float sum = 0;
      for (int k = 0; k < 40; k++)
      {
        sum += Distancetravelled[k];
      }

      printf("Distance= %lf \n ", sum);

      wait_us(500000);
      printf("%d\n\n", i);
    }
  }
}
    